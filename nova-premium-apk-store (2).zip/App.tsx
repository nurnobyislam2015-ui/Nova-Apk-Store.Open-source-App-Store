
import React, { useState, useMemo, useEffect } from 'react';
/* Corrected 'lucide-center' to 'lucide-react' and ensured icons are correctly imported */
import { Search, ShoppingBag, Share2, Check, Copy, TrendingUp, Sparkles, Zap, Package, LayoutGrid, Layout, Star, Download, Mic, MessageSquare, ArrowRight, Bot, Globe, ShieldCheck, X, ChevronRight, Filter, Volume2, MicOff, CloudOff, Activity, ShieldAlert, Terminal, AlertTriangle, Settings, Users } from 'lucide-react';
import { MOCK_APPS, APP_CATEGORIES } from './constants';
import { AppData, ViewState, User as UserType, Language, UpdateRequest } from './types';
import Sidebar from './components/Sidebar';
import AppCard from './components/AppCard';
import AppDetails from './components/AppDetails';
import Auth from './components/Auth';
import UserLibrary from './components/UserLibrary';
import SecurityCenter from './components/SecurityCenter';
import AdminPortal from './components/AdminPortal';
import AIStudio from './components/AIStudio';
import SubmitApp from './components/SubmitApp';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [lang, setLang] = useState<Language>('bn');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState(APP_CATEGORIES[0]);
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showShareToast, setShowShareToast] = useState(false);
  const [envWarning, setEnvWarning] = useState(false);
  
  const [currentUser, setCurrentUser] = useState<UserType | null>(() => {
    const saved = localStorage.getItem('nova_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [storeApps, setStoreApps] = useState<AppData[]>(() => {
    const saved = localStorage.getItem('nova_store_apps');
    const initialApps = MOCK_APPS.map(app => ({
      ...app,
      analytics: app.analytics || {
        totalInstalls: Math.floor(Math.random() * 50000),
        views: Math.floor(Math.random() * 100000),
        lastMonthInstalls: Math.floor(Math.random() * 5000),
        growthRate: 15.5,
        dailyActiveUsers: Array.from({length: 7}, () => Math.floor(Math.random() * 1000))
      }
    }));
    return saved ? JSON.parse(saved) : initialApps;
  });

  const [installedApps, setInstalledApps] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('nova_installed');
    return saved ? JSON.parse(saved) : {};
  });

  const [isInstalling, setIsInstalling] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('nova_store_apps', JSON.stringify(storeApps));
    
    // Safety check for API Key in Vercel environment
    const apiKey = (window as any).process?.env?.API_KEY || process.env.API_KEY;
    if (!apiKey && window.location.hostname !== 'localhost') {
      setEnvWarning(true);
    }

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [storeApps]);

  const filteredApps = useMemo(() => {
    return storeApps.filter(app => {
      const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = activeCategory === APP_CATEGORIES[0] || app.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory, storeApps]);

  const handleShare = async () => {
    const shareData = {
      title: 'Nova Premium APK Store',
      text: 'নোভা প্রিমিয়াম এপিকে স্টোর থেকে সব লেটেস্ট অ্যাপ ডাউনলোড করুন!',
      url: window.location.origin,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.url);
        setShowShareToast(true);
        setTimeout(() => setShowShareToast(false), 3000);
      }
    } catch (err) { console.error('Error sharing:', err); }
  };

  const handleApproveUpdate = (appId: string) => {
    setStoreApps(prev => prev.map(app => {
      if (app.id === appId && app.pendingUpdate) {
        return { ...app, version: app.pendingUpdate.version, releaseNotes: app.pendingUpdate.releaseNotes, pendingUpdate: undefined, status: 'published' as const };
      }
      return app;
    }));
  };

  const handleUpdateAppStatus = (appId: string, status: 'published' | 'rejected') => {
    setStoreApps(prev => prev.map(app => app.id === appId ? { ...app, status } : app));
  };

  const handleEditApp = (id: string, updatedData: Partial<AppData>) => {
    setStoreApps(prev => prev.map(app => app.id === id ? { ...app, ...updatedData } : app));
  };

  const handleImportApps = (importedApps: AppData[]) => setStoreApps(importedApps);
  const handleDeleteApp = (id: string) => setStoreApps(prev => prev.filter(app => app.id !== id));
  const handleFinishInstall = (id: string) => {
    setInstalledApps(prev => {
      const next = { ...prev, [id]: true };
      localStorage.setItem('nova_installed', JSON.stringify(next));
      return next;
    });
    setIsInstalling(null);
  };

  return (
    <div className={`flex min-h-screen ${isDarkMode ? 'dark bg-[#020617]' : 'bg-slate-50'} transition-colors duration-500 font-sans`}>
      <Sidebar 
        currentView={currentView} onNavigate={setCurrentView} 
        userRole={currentUser?.role || 'guest'} currentUser={currentUser} 
        isDarkMode={isDarkMode} toggleDarkMode={() => setIsDarkMode(!isDarkMode)} 
        lang={lang} setLang={setLang} isFirebaseConfigured={false} 
        isOnline={isOnline}
        onShare={handleShare}
      />
      
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        {/* Environment Alert for নূর নবী ইসলাম */}
        {envWarning && (
          <div className="bg-red-600 text-white px-6 py-3 flex items-center justify-between gap-3 text-[10px] font-black uppercase tracking-widest z-[100] shadow-2xl">
            <div className="flex items-center gap-3">
               <AlertTriangle size={16} /> 
               API_KEY Not Found in Vercel! AI Features are disabled. Please check Admin Portal.
            </div>
            <button onClick={() => setCurrentView('admin-portal')} className="px-4 py-1.5 bg-white text-red-600 rounded-lg flex items-center gap-2">
               <Settings size={12} /> Setup Now
            </button>
          </div>
        )}

        <header className="sticky top-0 z-40 px-6 py-4 flex flex-col gap-2 bg-white/80 dark:bg-[#020617]/80 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between">
            <div className="flex-1 max-w-xl relative mx-4">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder={lang === 'bn' ? 'অ্যাপ বা গেম খুঁজুন...' : 'Search apps or games...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-100 dark:bg-slate-900 border-none rounded-2xl py-3.5 pl-12 pr-12 text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-500/50 dark:text-white transition-all shadow-inner"
              />
            </div>

            <div className="flex items-center gap-3">
              <button onClick={() => setCurrentView('auth')} className="group relative w-11 h-11 rounded-2xl border-2 border-brand-500 overflow-hidden shadow-lg bg-brand-500/5 hover:scale-105 transition-all">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser?.name || 'Guest'}`} alt="User" />
              </button>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto scrollbar-hide px-4 md:px-10 py-8">
          {currentView === 'home' && (
            <div className="space-y-12 animate-slide-up pb-20">
               <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
                 {APP_CATEGORIES.map(cat => (
                   <button 
                    key={cat} 
                    onClick={() => setActiveCategory(cat)}
                    className={`px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border ${
                      activeCategory === cat ? 'bg-brand-600 border-brand-600 text-white shadow-brand shadow-xl' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-500 hover:border-brand-500/50'
                    }`}
                   >
                     {cat}
                   </button>
                 ))}
               </div>
               <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                {filteredApps.filter(a => a.status === 'published').map(app => (
                  <AppCard key={app.id} app={app} onClick={() => setSelectedAppId(app.id)} />
                ))}
              </div>
            </div>
          )}
          {currentView === 'security' && <SecurityCenter isDarkMode={isDarkMode} />}
          {currentView === 'ai-studio' && <AIStudio isDarkMode={isDarkMode} lang={lang} isOnline={isOnline} />}
          {currentView === 'admin-portal' && (
            <AdminPortal 
              apps={storeApps} userRole={currentUser?.role || 'guest'} lang={lang} 
              onDeleteApp={handleDeleteApp} onPublishApp={() => {}} onUpdateAppStatus={handleUpdateAppStatus} 
              onApproveUpdate={handleApproveUpdate} onEditApp={handleEditApp} onImportApps={handleImportApps}
            />
          )}
          {currentView === 'submit-app' && <SubmitApp lang={lang} isDarkMode={isDarkMode} onOfflineSubmit={(app) => {
            const appWithId: AppData = { ...app, id: Math.random().toString(36).substr(2, 9) };
            setStoreApps(prev => [appWithId, ...prev]);
            setCurrentView('home');
          }} />}
          {currentView === 'installed' && (
            <UserLibrary 
              lang={lang} installedApps={storeApps.filter(a => installedApps[a.id])} 
              userSubmissions={storeApps.filter(a => a.submittedBy === currentUser?.id || (currentUser?.role === 'admin'))} 
              onUninstall={id => { setInstalledApps(prev => { const n = {...prev}; delete n[id]; localStorage.setItem('nova_installed', JSON.stringify(n)); return n; }); }}
              onUpdateApp={() => {}} onSubmitUpdate={(appId, update) => setStoreApps(prev => prev.map(app => app.id === appId ? { ...app, pendingUpdate: update } : app))} 
              currentUser={currentUser} isDarkMode={isDarkMode} 
            />
          )}
          {currentView === 'auth' && <Auth onLogin={(user) => { setCurrentUser(user); localStorage.setItem('nova_user', JSON.stringify(user)); }} onClose={() => setCurrentView('home')} />}
        </div>

        {selectedAppId && (
          <AppDetails 
            lang={lang} app={storeApps.find(a => a.id === selectedAppId)!} onClose={() => setSelectedAppId(null)} 
            onAddReview={() => {}} onInstall={() => setIsInstalling(selectedAppId)} onFinishInstall={() => handleFinishInstall(selectedAppId)}
            isInstalled={!!installedApps[selectedAppId]} isInstalling={isInstalling === selectedAppId} isDarkMode={isDarkMode} isOnline={isOnline}
          />
        )}

        {showShareToast && (
          <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] animate-slide-up">
            <div className="bg-slate-900 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-white/10">
              <Check className="text-emerald-400" size={18} />
              <span className="text-xs font-black uppercase tracking-widest">Link Copied!</span>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
