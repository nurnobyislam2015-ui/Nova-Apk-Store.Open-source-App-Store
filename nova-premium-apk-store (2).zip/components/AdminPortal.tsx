
import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, TrendingUp, BarChart3, Rocket, Settings, Trash2, Power, Check, 
  LayoutGrid, Terminal, Smartphone, Globe, Lock, Search, Share2, Server, Star, 
  CloudUpload, Info, AlertCircle, Copy, Code2, ExternalLink, Zap, Wifi, Activity, 
  Database, Cpu, Package, ArrowUpCircle, History, RefreshCcw, Loader2, Edit3, X, 
  Save, DownloadCloud, UploadCloud, Globe2, Shield, Link2, Users, HelpCircle, 
  AlertTriangle, Github, ArrowRight, MousePointer2, Command, FileJson, FileCode
} from 'lucide-react';
import { AppData, UserRole, Language } from '../types';

interface AdminPortalProps {
  apps: AppData[];
  onPublishApp: (app: AppData) => void;
  onDeleteApp: (id: string) => void;
  onUpdateAppStatus: (appId: string, status: 'published' | 'rejected') => void;
  onApproveUpdate: (appId: string) => void;
  onEditApp: (id: string, data: Partial<AppData>) => void;
  onImportApps?: (apps: AppData[]) => void;
  userRole: UserRole;
  lang: Language;
}

const AdminPortal: React.FC<AdminPortalProps> = ({ apps, userRole, lang, onDeleteApp, onUpdateAppStatus, onApproveUpdate, onEditApp, onImportApps }) => {
  const [activeAdminTab, setActiveAdminTab] = useState<'dashboard' | 'apps' | 'hosting' | 'fix-guide'>('fix-guide');
  const [cpuUsage, setCpuUsage] = useState(12);

  const currentHost = window.location.hostname;

  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(Math.floor(Math.random() * (22 - 5 + 1) + 5));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  if (userRole !== 'admin') return (
    <div className="min-h-screen flex items-center justify-center p-8 bg-slate-950">
       <div className="text-center space-y-6">
          <div className="w-24 h-24 bg-red-500/10 border border-red-500/20 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse">
             <Lock size={40} className="text-red-500" />
          </div>
          <h2 className="text-4xl font-black text-white tracking-tighter uppercase">অ্যাক্সেস ডিনাইড</h2>
          <p className="text-slate-500 font-bold uppercase text-xs tracking-[0.3em]">শুধুমাত্র মালিক "নূর নবী ইসলাম" এটি দেখতে পারবেন।</p>
       </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto py-12 space-y-12 animate-slide-up px-6 pb-24">
      {/* Noble Header for Noby Islam */}
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 bg-gradient-to-br from-slate-900 via-slate-950 to-brand-950 p-12 rounded-[4rem] text-white shadow-2xl relative overflow-hidden border border-white/5">
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
             <div className="px-4 py-1.5 bg-brand-500 text-[10px] font-black uppercase rounded-full tracking-widest shadow-lg shadow-brand-500/30">Admin Central</div>
             <div className="flex items-center gap-2 text-emerald-400 text-[10px] font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div> সিস্টেম অনলাইন
             </div>
          </div>
          <h2 className="text-5xl md:text-7xl font-black tracking-tighter mb-4 leading-none">Md Nur Noby<br/><span className="text-brand-400">Islam</span></h2>
          <p className="text-slate-400 font-medium max-w-xl text-lg">Nova APK Store-এর মালিকানা প্যানেল। এখান থেকে আপনি সার্ভার ফিক্স এবং অ্যাপ ম্যানেজ করতে পারবেন।</p>
        </div>
        
        <div className="relative z-10 bg-white/5 backdrop-blur-2xl p-8 rounded-[3rem] border border-white/10 flex flex-col items-center gap-4 min-w-[280px]">
           <Server size={32} className="text-brand-500" />
           <div className="text-center">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">সার্ভার এড্রেস</p>
              <p className="text-lg font-black text-white truncate max-w-[200px]">{currentHost}</p>
           </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="flex gap-2 p-2 bg-slate-100 dark:bg-slate-900/50 rounded-[3rem] w-fit border dark:border-slate-800 overflow-x-auto scrollbar-hide shadow-inner">
        {[
          { id: 'fix-guide', label: 'গিটহাব আপলোড গাইড', icon: HelpCircle },
          { id: 'dashboard', label: 'সার্ভার স্ট্যাটাস', icon: Activity },
          { id: 'apps', label: 'অ্যাপ লিস্ট', icon: Smartphone },
          { id: 'hosting', label: 'Vercel সেটিংস', icon: Globe2 },
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveAdminTab(tab.id as any)}
            className={`flex items-center gap-3 px-8 py-4 rounded-[2.5rem] text-[11px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
              activeAdminTab === tab.id ? 'bg-brand-600 text-white shadow-xl shadow-brand-500/20' : 'text-slate-500 hover:text-brand-500'
            }`}
          >
            <tab.icon size={16} /> {tab.label}
          </button>
        ))}
      </div>

      {/* The Crucial Fix Guide for Noby Islam */}
      {activeAdminTab === 'fix-guide' && (
        <div className="animate-slide-up space-y-8">
           <div className="bg-brand-500/10 border border-brand-500/20 p-12 rounded-[4rem] text-slate-900 dark:text-white">
              <div className="flex items-center gap-6 mb-12">
                 <div className="p-4 bg-brand-600 rounded-3xl text-white shadow-brand">
                    <Github size={32} />
                 </div>
                 <div>
                    <h4 className="text-4xl font-black uppercase tracking-tight">আপনার গিটহাব রিপোজিটরি সেটআপ</h4>
                    <p className="text-brand-600 font-bold uppercase text-[10px] tracking-widest">নূর নবী ভাই, নিচের ধাপগুলো অনুসরণ করে সব ঠিক করুন</p>
                 </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="bg-white dark:bg-slate-900 p-10 rounded-[3.5rem] shadow-sm border dark:border-slate-800 space-y-6">
                    <div className="flex items-center gap-3">
                       <FileCode className="text-brand-500" />
                       <h5 className="font-black text-xl uppercase tracking-tighter">ধাপ ১: ফাইল তৈরি</h5>
                    </div>
                    <p className="text-sm text-slate-500 leading-relaxed font-medium">
                       আমার দেওয়া সব কোড কপি করে আপনার কম্পিউটারে বা মোবাইলে নিচের নামে ফাইলগুলো তৈরি করুন:
                    </p>
                    <ul className="space-y-2">
                       {['index.html', 'index.tsx', 'App.tsx', 'types.ts', 'constants.ts'].map(f => (
                         <li key={f} className="flex items-center gap-2 text-[11px] font-black text-brand-600 bg-brand-50 dark:bg-brand-900/20 px-3 py-1.5 rounded-lg border border-brand-100 dark:border-brand-800">
                            <Check size={12} /> {f}
                         </li>
                       ))}
                    </ul>
                 </div>

                 <div className="bg-white dark:bg-slate-900 p-10 rounded-[3.5rem] shadow-sm border dark:border-slate-800 space-y-6">
                    <div className="flex items-center gap-3">
                       <CloudUpload className="text-emerald-500" />
                       <h5 className="font-black text-xl uppercase tracking-tighter">ধাপ ২: গিটহাবে আপলোড</h5>
                    </div>
                    <p className="text-sm text-slate-500 leading-relaxed font-medium">
                       আপনার GitHub-এর **New Repository** টি ওপেন করুন। সেখানে **"Add file"** > **"Upload files"** এ ক্লিক করে আপনার সব ফাইলগুলো ড্র্যাগ করে ছেড়ে দিন। তারপর **Commit changes** এ ক্লিক করুন।
                    </p>
                    <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-emerald-600 text-[10px] font-black uppercase tracking-widest text-center">
                       আপলোড শেষ হলে Vercel অটোমেটিক অ্যাপ চালু করবে
                    </div>
                 </div>
              </div>

              <div className="mt-8 p-10 bg-slate-900 text-white rounded-[3.5rem] flex flex-col md:flex-row items-center justify-between gap-6 border border-white/5">
                 <div className="flex items-center gap-5">
                    <div className="p-4 bg-white/10 rounded-2xl">
                       <Zap className="text-brand-400" />
                    </div>
                    <div>
                       <h6 className="font-black text-lg">শেষ ধাপ: Vercel এপিআই কী</h6>
                       <p className="text-slate-400 text-sm">Vercel ড্যাশবোর্ডে গিয়ে API_KEY সেট করতে ভুলবেন না।</p>
                    </div>
                 </div>
                 <button onClick={() => setActiveAdminTab('hosting')} className="px-10 py-4 bg-brand-600 hover:bg-brand-700 rounded-2xl font-black text-[11px] uppercase tracking-widest transition-all">
                    হোস্টিং গাইড দেখুন
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* Dashboard View */}
      {activeAdminTab === 'dashboard' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 animate-slide-up">
           <div className="bg-white dark:bg-slate-900 p-10 rounded-[4rem] border dark:border-slate-800 shadow-premium">
              <div className="flex items-center justify-between mb-8">
                 <h4 className="text-lg font-black dark:text-white uppercase tracking-tighter">সার্ভার লোড</h4>
                 <Cpu className="text-brand-500" size={20} />
              </div>
              <div className="text-6xl font-black text-brand-600 mb-4">{cpuUsage}%</div>
              <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                 <div className="h-full bg-brand-600 transition-all duration-1000" style={{ width: `${cpuUsage}%` }}></div>
              </div>
           </div>

           <div className="bg-white dark:bg-slate-900 p-10 rounded-[4rem] border dark:border-slate-800 shadow-premium text-center">
              <Activity className="text-emerald-500 mx-auto mb-6" size={40} />
              <p className="text-lg font-black dark:text-white uppercase tracking-tighter">Mainframe Status</p>
              <p className="text-sm text-slate-500 mt-2">আপনার সিস্টেম পুরোপুরি সুরক্ষিত এবং একটিভ।</p>
           </div>

           <div className="bg-white dark:bg-slate-900 p-10 rounded-[4rem] border dark:border-slate-800 shadow-premium text-center">
              <Users className="text-brand-500 mx-auto mb-6" size={40} />
              <p className="text-lg font-black dark:text-white uppercase tracking-tighter">গ্লোবাল অ্যাক্সেস</p>
              <p className="text-sm text-slate-500 mt-2">নোভা ক্লাউড নেটওয়ার্কের সাথে কানেক্টেড।</p>
           </div>
        </div>
      )}

      {/* Hosting Tab */}
      {activeAdminTab === 'hosting' && (
        <div className="space-y-8 animate-slide-up">
           <div className="bg-slate-950 p-12 rounded-[4rem] text-white shadow-2xl relative overflow-hidden">
              <h4 className="text-2xl font-black mb-8 flex items-center gap-3 text-brand-400">
                <Globe size={24} /> Vercel Environment Variables
              </h4>
              <div className="space-y-8">
                 <p className="text-slate-400 font-medium">নূর নবী ইসলাম ভাই, আপনার Vercel ড্যাশবোর্ডে গিয়ে এই ভেরিয়েবলটি বসাতে হবে:</p>
                 <div className="p-8 bg-white/5 rounded-3xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                       <span className="px-4 py-1.5 bg-brand-600 rounded-lg text-[10px] font-black">KEY</span>
                       <span className="font-mono text-lg">API_KEY</span>
                    </div>
                    <div className="flex items-center gap-4">
                       <span className="px-4 py-1.5 bg-slate-800 rounded-lg text-[10px] font-black">VALUE</span>
                       <span className="font-mono text-slate-500">আপনার Gemini এপিআই কী</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Footer Branding */}
      <footer className="text-center pt-12">
         <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-950 rounded-full text-white text-[11px] font-black uppercase tracking-[0.3em] shadow-2xl border border-white/5">
            <Command size={14} className="text-brand-500" /> Authorized System of Md Nur Noby Islam
         </div>
      </footer>
    </div>
  );
};

export default AdminPortal;
